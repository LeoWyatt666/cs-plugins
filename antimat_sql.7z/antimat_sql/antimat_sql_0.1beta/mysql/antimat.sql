DROP DATABASE IF EXISTS `antimat`;
CREATE DATABASE `antimat`
USE `antimat`;

DROP TABLE IF EXISTS `b_logs`;
CREATE TABLE `b_logs` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_name` varchar(32) DEFAULT NULL,
  `p_msg` varchar(255) DEFAULT '',
  `p_ip` varchar(15) DEFAULT NULL,
  `p_steamid` varchar(32) DEFAULT NULL,
  `p_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`p_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0;

DROP TABLE IF EXISTS `c_words`;
CREATE TABLE `c_words` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_words` varchar(32) DEFAULT NULL,
  `p_repls` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`p_id`),
  FULLTEXT KEY `i_word` (`p_words`)
) ENGINE=MyISAM AUTO_INCREMENT=0;

INSERT INTO `c_words` VALUES (1,'syka',NULL);
INSERT INTO `c_words` VALUES (3,'pidor',NULL);
INSERT INTO `c_words` VALUES (6,'pi3dec',NULL);
INSERT INTO `c_words` VALUES (8,'blya',NULL);
INSERT INTO `c_words` VALUES (10,'eblan',NULL);
INSERT INTO `c_words` VALUES (11,'eban',NULL);
INSERT INTO `c_words` VALUES (12,'yob',NULL);
INSERT INTO `c_words` VALUES (13,'huli',NULL);
INSERT INTO `c_words` VALUES (14,'7uga',NULL);
INSERT INTO `c_words` VALUES (15,'nugp',NULL);
INSERT INTO `c_words` VALUES (16,'nugep',NULL);
INSERT INTO `c_words` VALUES (17,'nuda',NULL);
INSERT INTO `c_words` VALUES (18,'nudp',NULL);
INSERT INTO `c_words` VALUES (19,'nudr',NULL);
INSERT INTO `c_words` VALUES (20,'pudp',NULL);
INSERT INTO `c_words` VALUES (21,'pi3da',NULL);
INSERT INTO `c_words` VALUES (22,'7u3g',NULL);
INSERT INTO `c_words` VALUES (23,'nu3g',NULL);
INSERT INTO `c_words` VALUES (25,'pi3d',NULL);
INSERT INTO `c_words` VALUES (26,'zopa',NULL);
INSERT INTO `c_words` VALUES (27,'zadrot',NULL);
INSERT INTO `c_words` VALUES (28,'suka',NULL);
INSERT INTO `c_words` VALUES (29,'cyka',NULL);
INSERT INTO `c_words` VALUES (30,'such',NULL);
INSERT INTO `c_words` VALUES (31,'suki',NULL);
INSERT INTO `c_words` VALUES (32,'su4k',NULL);
INSERT INTO `c_words` VALUES (33,'cy4k',NULL);
INSERT INTO `c_words` VALUES (34,'cuka',NULL);
INSERT INTO `c_words` VALUES (35,'cuki',NULL);
INSERT INTO `c_words` VALUES (36,'cuku',NULL);
INSERT INTO `c_words` VALUES (37,'paskud',NULL);
INSERT INTO `c_words` VALUES (38,'loshar',NULL);
INSERT INTO `c_words` VALUES (39,'loh',NULL);
INSERT INTO `c_words` VALUES (40,'lox',NULL);
INSERT INTO `c_words` VALUES (41,'sosi',NULL);
INSERT INTO `c_words` VALUES (42,'COCU',NULL);
INSERT INTO `c_words` VALUES (43,'coco',NULL);
INSERT INTO `c_words` VALUES (44,'zaebal',NULL);
INSERT INTO `c_words` VALUES (45,'zaibal',NULL);
INSERT INTO `c_words` VALUES (46,'ueban',NULL);
INSERT INTO `c_words` VALUES (47,'27015',NULL);
INSERT INTO `c_words` VALUES (48,'27016',NULL);
INSERT INTO `c_words` VALUES (49,'27017',NULL);
INSERT INTO `c_words` VALUES (50,'27018',NULL);
INSERT INTO `c_words` VALUES (51,'IIu3ga',NULL);
INSERT INTO `c_words` VALUES (52,'suka',NULL);
INSERT INTO `c_words` VALUES (53,'suchka',NULL);
INSERT INTO `c_words` VALUES (54,'sychka',NULL);
INSERT INTO `c_words` VALUES (55,'cuchka',NULL);
INSERT INTO `c_words` VALUES (56,'cychka',NULL);
INSERT INTO `c_words` VALUES (57,'pidar',NULL);
INSERT INTO `c_words` VALUES (58,'blia',NULL);
INSERT INTO `c_words` VALUES (59,'ebal',NULL);
INSERT INTO `c_words` VALUES (60,'ebu',NULL);
INSERT INTO `c_words` VALUES (61,'4mo',NULL);
INSERT INTO `c_words` VALUES (62,'chmo',NULL);
INSERT INTO `c_words` VALUES (63,'eblan',NULL);
INSERT INTO `c_words` VALUES (64,'E6AH',NULL);
INSERT INTO `c_words` VALUES (65,'gondon',NULL);
INSERT INTO `c_words` VALUES (66,'mudak',NULL);
INSERT INTO `c_words` VALUES (67,'mydak',NULL);
INSERT INTO `c_words` VALUES (68,'MyDUJIO',NULL);
INSERT INTO `c_words` VALUES (69,'FuCkEr',NULL);
INSERT INTO `c_words` VALUES (70,'FuCk',NULL);
INSERT INTO `c_words` VALUES (71,'FAK',NULL);
INSERT INTO `c_words` VALUES (72,'FAC',NULL);
INSERT INTO `c_words` VALUES (73,'xer',NULL);
INSERT INTO `c_words` VALUES (74,'xyi',NULL);
INSERT INTO `c_words` VALUES (75,'xui',NULL);
INSERT INTO `c_words` VALUES (76,'xyina',NULL);
INSERT INTO `c_words` VALUES (77,'xuina',NULL);
INSERT INTO `c_words` VALUES (78,'poxyi',NULL);
INSERT INTO `c_words` VALUES (79,'poxui',NULL);
INSERT INTO `c_words` VALUES (80,'pox',NULL);
INSERT INTO `c_words` VALUES (81,'HAX',NULL);
INSERT INTO `c_words` VALUES (82,'nax',NULL);
INSERT INTO `c_words` VALUES (83,'JIOX',NULL);
INSERT INTO `c_words` VALUES (84,'JlOX',NULL);
INSERT INTO `c_words` VALUES (85,'DPO4UT',NULL);
INSERT INTO `c_words` VALUES (86,'roHDOH',NULL);
INSERT INTO `c_words` VALUES (87,'rOHDON',NULL);
INSERT INTO `c_words` VALUES (88,'raHDON',NULL);
INSERT INTO `c_words` VALUES (89,'roNDON',NULL);
INSERT INTO `c_words` VALUES (90,'roNDOH',NULL);
INSERT INTO `c_words` VALUES (91,'pidr',NULL);
INSERT INTO `c_words` VALUES (92,'pidrilo',NULL);
INSERT INTO `c_words` VALUES (93,'pida',NULL);
INSERT INTO `c_words` VALUES (94,'bl9',NULL);
INSERT INTO `c_words` VALUES (95,'ml9',NULL);
INSERT INTO `c_words` VALUES (96,'nah',NULL);
INSERT INTO `c_words` VALUES (97,'6la',NULL);
INSERT INTO `c_words` VALUES (98,'sy4ka',NULL);
INSERT INTO `c_words` VALUES (99,'ckotuHa',NULL);
INSERT INTO `c_words` VALUES (100,'Padla',NULL);
INSERT INTO `c_words` VALUES (101,'ni3dec',NULL);
INSERT INTO `c_words` VALUES (102,'pzdc',NULL);
INSERT INTO `c_words` VALUES (103,'kor9vbIu',NULL);
INSERT INTO `c_words` VALUES (104,'1488',NULL);
INSERT INTO `c_words` VALUES (105,'14/88',NULL);
INSERT INTO `c_words` VALUES (106,'14-88',NULL);
INSERT INTO `c_words` VALUES (107,'14_88',NULL);
INSERT INTO `c_words` VALUES (108,'6jl9',NULL);
INSERT INTO `c_words` VALUES (109,'6Jl9',NULL);
INSERT INTO `c_words` VALUES (110,'6jI9',NULL);
INSERT INTO `c_words` VALUES (111,'6ji9',NULL);
INSERT INTO `c_words` VALUES (112,'6j19',NULL);
INSERT INTO `c_words` VALUES (113,'coli',NULL);
INSERT INTO `c_words` VALUES (114,'pizd',NULL);